package OAuthFlow.Handlers;public class AuthorizationHandler {
}
