package OAuthFlow.GrantsImplementation;

public class ImplicitGrant extends OAuthFlow {

    @Override
    protected void create_authorization_request() {

    }

    @Override
    protected void get_access_token() {

    }

    @Override
    protected void validate_access_token() {

    }

    @Override
    protected void get_user_info() {

    }

    @Override
    protected void logout() {

    }
}
