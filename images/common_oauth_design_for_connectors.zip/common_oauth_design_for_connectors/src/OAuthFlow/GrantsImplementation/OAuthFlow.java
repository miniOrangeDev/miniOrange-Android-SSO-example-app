package OAuthFlow.GrantsImplementation;

public abstract class OAuthFlow {

    abstract protected void create_authorization_request();

    abstract protected void get_access_token();

    abstract protected void validate_access_token();

    abstract protected void get_user_info();

    abstract protected void logout();

    public void validate_authorization_code() {

    }

}
