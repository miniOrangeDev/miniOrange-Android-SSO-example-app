package OAuthFlow.Utils;

public class UrlEndpointUtils {

    public String createTokenUrl(String baseUrl){
        return "";

    }
    public String createAuthorizationUrl(String baseUrl){
        return "";

    }
    public String createRevocationUrl(String baseUrl){
        return "";

    }
    public String createIntrospectionUrl(String baseUrl){
        return "";

    }
    public String createUserInfoUrl(String baseUrl){
        return "";

    }
    public String createLogoutUrl(String baseUrl){
        return "";

    }
}
