package OAuthFlow.Constants;

public enum GrantType {
    AUTHORIZATION_CODE,
    PKCE,
    PASSWORD,
    IMPLICIT
}
