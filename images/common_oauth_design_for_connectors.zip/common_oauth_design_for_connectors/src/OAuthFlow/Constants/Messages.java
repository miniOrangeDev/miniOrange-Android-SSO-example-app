package OAuthFlow.Constants;

public enum Messages {

}
