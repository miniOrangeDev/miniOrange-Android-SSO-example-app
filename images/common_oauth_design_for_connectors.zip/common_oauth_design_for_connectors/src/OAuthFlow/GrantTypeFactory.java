package OAuthFlow;

import OAuthFlow.Constants.GrantType;
import OAuthFlow.GrantsImplementation.*;

public class GrantTypeFactory {

    public static OAuthFlow getGrantType(GrantType grantType) {
        switch (grantType) {
            case IMPLICIT:
                return new ImplicitGrant();
            case PKCE:
                return new PKCEGrant();
            case PASSWORD:
                return new PasswordGrant();
            default:
                return new AuthorizationCodeGrant();
        }
    }
}
